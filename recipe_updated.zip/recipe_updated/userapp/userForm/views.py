from django.shortcuts import render,redirect, get_object_or_404
from .models import userModel, toDoModel
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.decorators import login_required

# Create your views here.
def index(request):
    tasks = toDoModel.objects.all()
    return render(request, 'index.html',{'tasks': tasks})


def login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            request.session['user_id'] = user.id
            messages.success(request, "Login successfull")
            return redirect('/toDo/')
        else:
            # Authentication failed, display error message
            messages.error(request, "Invalid username or password. Please try again.")
            return render(request, 'login.html')

    return render(request, 'login.html')

def register(request):
    if request.method == "POST":
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        user = User.objects.create_user(username= username, email = email, password = password)
        user.first_name = fname
        user.last_name = lname
        user.save()
        messages.success(request, "Registered successfully")

    return render(request, 'register.html')


def logout(request):
    auth_logout(request)
    return redirect('/')



@login_required
def toDo(request):
    if request.method == "POST":
        action = request.POST.get('action')
        task_id = request.POST.get('task_id')
        task_text = request.POST.get('task')
        task_desc1=request.POST.get('Desc')

        if action == 'add':
            if task_text:
                todo = toDoModel(username=request.user, task=task_text,task_desc=task_desc1)
                todo.save()
                messages.success(request, 'Task added')
            else:
                messages.error(request, 'Task cannot be empty')
        elif action == 'edit':
            task = get_object_or_404(toDoModel, id=task_id, username=request.user)
            task.task = task_text
            task.task_desc = task_desc1

            task.save(update_fields=['task','task_desc'])

            #task.save(update_fields=['task']) # Only update the task field
            messages.success(request, 'Task updated')
        elif action == 'delete':
            task = get_object_or_404(toDoModel, id=task_id, username=request.user)
            task.delete()
            messages.success(request, 'Task deleted')

        return redirect('/toDo')

    tasks = toDoModel.objects.filter(username = request.user)
    return render(request, 'toDo.html', {'tasks': tasks})